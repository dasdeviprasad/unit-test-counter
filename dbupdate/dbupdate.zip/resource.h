//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by dbupdate.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_DBUPDATE_DIALOG             102
#define IDS_SQL_ERROR                   102
#define IDS_SQL_INVALID_HANDLE          103
#define IDS_FMT_DATABASE_ERROR          104
#define IDS_ERROR                       105
#define IDR_MAINFRAME                   128
#define IDC_UPDATE_STATUS               1000

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
